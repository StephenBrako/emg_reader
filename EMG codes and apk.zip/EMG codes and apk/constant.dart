import 'package:flutter/material.dart';

// Colors
const mPrimaryTextColor = Color(0xFF25257E);
const mTitleTextColor = Color(0xFF25257E);
const mBackgroundColor = Color(0xFFFDFCFF);
const mSecondBackgroundColor = Color(0xFFBCCBF3);
const mButtonColor = Color(0xFF5063FF);
const mYellowColor = Color(0xFFFB7B11);